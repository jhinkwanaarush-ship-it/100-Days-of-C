//Write a program to check if a number is a palindrome.

#include <stdio.h>

int main(){
    int n,c,s=0,r;
    
    printf("enter any number : ");
    scanf("%d",&n);
    
    c=n;
    
    while(n>0){
        r=n%10;
        s=r+(s*10);
        n=n/10;
    }
    if(c==s){
        printf("palindrome ");
    }
    else{
        printf("not a palindrome");
    }
    return 0;
}