/*
Q1: Write a program to input two numbers and display their sum.
*/
#include <stdio.h>

int main() {
    int a, b;
    printf("enter two numbers: ");
    scanf("%d %d", &a, &b);
    printf("Sum = %d\n", a + b);
    return 0;
}

