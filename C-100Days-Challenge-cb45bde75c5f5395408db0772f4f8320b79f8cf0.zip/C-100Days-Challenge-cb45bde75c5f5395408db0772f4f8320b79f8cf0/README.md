# C-100Days-Challenge
100 C programming problems solved as part of the UPES Dehradun 100 Days Coding Challenge. Each solution includes the problem statement, verified code, and test case outputs.
